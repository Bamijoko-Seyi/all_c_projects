#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "rotate.h"

void check(unsigned int input, int bits, unsigned int expected_output_left, unsigned int expected_output_right)
{
    
    printf("Rotate 0x%x left by %d. Expected: 0x%x - ", input, bits, expected_output_left);
    assert(rotate_left(input, bits) == expected_output_left);
    printf("Pass\n");
    printf("Rotate 0x%x right by %d. Expected: 0x%x - ", input, bits, expected_output_right);
    assert(rotate_right(input, bits) == expected_output_right);
    printf("Pass\n");
}

int main(int argc, char* argv[]){
    unsigned int input, expected_output_left,expected_output_right;
    int bits;

    if (argc != 2)
    {
        printf("Usage: ./rotate.c number\n");
        return -1;
    }
    int test = atoi(argv[1]);
    switch(test) 
    {
    case 0:
        input = 0x55667788;
        bits = 1;
        expected_output_left = 0xaaccef10;
        expected_output_right = 0x2ab33bc4;
        check(input, bits, expected_output_left,expected_output_right);
        break;
    case 1:
        input = 0x12349876;
        bits = 12;
        expected_output_left = 0x49876123;
        expected_output_right = 0x87612349;
        check(input, bits, expected_output_left,expected_output_right);
        break;
    case 2:
        input = 0x66667777;
        bits = 8;
        expected_output_left = 0x66777766;
        expected_output_right = 0x77666677;
        check(input, bits, expected_output_left,expected_output_right);
        break;
    case 3:
        input = 0x25667782;
        bits = 10;
        expected_output_left = 0x99de0895;
        expected_output_right = 0xe089599d;
        check(input, bits, expected_output_left,expected_output_right);
        break;
    }

    return 0;
}
