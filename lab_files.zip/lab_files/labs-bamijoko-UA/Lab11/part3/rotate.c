#include <stdio.h>
#include <stdlib.h>
#include "rotate.h"

unsigned int rotate_left(unsigned int i, int n){
    unsigned int result = (i << n) | (i >> (sizeof(unsigned int) * 8 - n));
    return result;
}

unsigned int rotate_right(unsigned int i, int n){
    unsigned int result = (i >> n) | (i << (sizeof(unsigned int) * 8 - n));
    return result;
}