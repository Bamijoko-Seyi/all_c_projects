#ifndef __ROTATE_H__
#define __ROTATE_H__

unsigned int rotate_left(unsigned int i, int n);
unsigned int rotate_right(unsigned int i, int n);

#endif
