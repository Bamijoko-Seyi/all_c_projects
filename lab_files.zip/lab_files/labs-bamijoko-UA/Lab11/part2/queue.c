#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

struct node {
    Item data;
    struct node *next;
};

struct queue_type {
    struct node *front;
    struct node *end;
};

void enqueue(Queue *queue, Item x) {
    struct node *new_node = malloc(sizeof(struct node));
    new_node->data = x;
    new_node->next = NULL;
    if ((*queue) == NULL) {
        (*queue) = malloc(sizeof(struct queue_type));
        (*queue)->front = new_node;
        (*queue)->end = new_node;
    } else {
        (*queue)->end->next = new_node;
    }
    (*queue)->end = new_node;
    new_node = NULL;
}

void dequeue(Queue *queue) {
    if ((*queue) == NULL) {
        return;
    }
    struct node *current_node = (*queue)->front;
    (*queue)->front = current_node->next;
    if ((*queue)->front == NULL) {
        (*queue)->end = NULL;
        free(current_node);
        free((*queue));
        (*queue) = NULL;
    } else {
        free(current_node);
    }
}


void print_queue(Queue queue) {
    struct node *current_node = queue->front;
    while (current_node != NULL) {
        printf("%d\n", current_node->data);
        current_node = current_node->next;
    }
}
