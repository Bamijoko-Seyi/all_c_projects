#ifndef __QUEUE_H__
#define __QUEUE_H__

typedef int Item;

typedef struct queue_type *Queue;

void enqueue(Queue *queue, Item x);
void dequeue(Queue *queue);
void print_queue(Queue queue);

#endif
