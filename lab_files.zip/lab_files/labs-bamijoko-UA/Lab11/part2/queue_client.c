#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main(void)
{
    Queue queue = NULL; 
    for (int i = 0; i < 3; i++)
    {
        enqueue(&queue, i);
    }
    printf("Printing queue 0 1 2\n");
    print_queue(queue);
    for (int i = 0; i < 3; i++)
    {
        dequeue(&queue);
    }
    printf("Printing queue 3 4\n");
    for (int i = 3; i < 5; i++)
    {
        enqueue(&queue, i);
    }
    print_queue(queue);
    for (int i = 0; i < 2; i++)
    {
        dequeue(&queue);
    }
}
