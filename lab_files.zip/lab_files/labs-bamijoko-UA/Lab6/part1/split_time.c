/*******************************************
 split_time.c 
 Author: Bammijoko Oluwaseyfunmi 
 Last updated: 2/28
 *******************************************/
#include <stdio.h>
#include <stdlib.h>

void split_time(long total_sec, int *hr, int *min, int *sec);

void split_time(long total_sec, int *hr, int *min, int *sec){
    float decimal_part;
    *hr = (int)(total_sec / 3600);
    decimal_part = total_sec - *hr * 3600;
    *min = (int)(decimal_part / 60);
    decimal_part = decimal_part - *min * 60;
    *sec = (int)decimal_part;
    if((*hr < 0 || *hr > 23) || (*min < 0 || *min > 59) || (*sec < 0 || *sec > 59)){
        fprintf(stderr,"Total time limit exceded \n");
        exit(0);
    }
}

int main(int argc, char * argv[]){
    long total_sec = atol(argv[1]);
    int hr, min, sec;
    split_time(total_sec, &hr, &min, &sec);
    printf("Converted time = %02d:%02d:%02d \n",hr,min,sec);
    return 0;
}
