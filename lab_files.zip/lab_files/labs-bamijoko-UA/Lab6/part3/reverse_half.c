#include <stdio.h>
#include <stdlib.h>
int main() {
    char input[100],result_character[50];  // declare a character array to store the user's input
    int input_size,j = 0;
    printf("Enter a message: ");
    fgets(input, sizeof(input), stdin);  // read a line of text from the user
    for(int i = 0; i < 100; i++){
        if(*(input + i) == '\n'){
            input_size = i;
            //add 
            break;
        }
    }
    //input_size--;
    int midpoint = input_size / 2;

    for(int i = midpoint - 1; i >= 0; i--){
        *(result_character + j) = *(input + i);
        j++;
    }

    *(result_character + (++j)) ='\0';
    printf("Reversal of first half: ");

    for(int i = 0; i < 100; i++){
        if(*(result_character + i) == '\0'){
            break;
        }
        printf("%c",*(result_character + i));
    }
    printf("\n");
    return 0;
}