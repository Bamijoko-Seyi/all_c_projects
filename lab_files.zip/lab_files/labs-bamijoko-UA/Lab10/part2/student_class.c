#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
int studentID;
char name[20];
} Student;

int main(){
    int input,input_id,original_size = 2,remaining_spots = 5,found_empty = 0;
    char input_name[20];
    Student *student_array = malloc(original_size * sizeof(Student));
    for(int i = 0; i < original_size; i++){
                    //student_array[i] = NULL;
                    //student_array[i].studentID = NULL;
                    student_array[i].studentID = 0;
                    strcpy(student_array[i].name, "\0");
            }

    for(;;){
        if(remaining_spots == 0){
            break;
        }
        printf("Enter operation: ");
        scanf("%d",&input);
        if(input == 0){
            break;
        }
        if(input == 1){
           //if(remaining_spots <= 3){}
            printf("Enter ID to add (%d spots available): ",remaining_spots);
            scanf("%d",&input_id);
            printf("Enter student name: ");
            scanf("%s",input_name);
            found_empty = 0;
            for(int i = 0; i < original_size; i++){
                if(student_array[i].studentID == 0 && (strcmp(student_array[i].name,"\0") == 0)){
                    student_array[i].studentID = input_id;
                    strcpy(student_array[i].name, input_name);
                    found_empty = 1;
                    remaining_spots--;
                    break;
                }
            }
            if(found_empty == 0){
                student_array = realloc(student_array, (original_size + 1) * sizeof(Student));
                student_array[original_size].studentID = input_id;
                strcpy(student_array[original_size].name, input_name);
                original_size++;
                remaining_spots--;
            }
        }
        if(input == 2){
            printf("Enter ID to drop: ");
            scanf("%d",&input_id);
            for(int i = 0; i < original_size; i++){
                if(student_array[i].studentID == input_id){
                    student_array[i].studentID = 0;
                    strcpy(student_array[i].name, "\0");
                    remaining_spots++;
                    break;
                }
            }
        }
    }
    if(remaining_spots == 0){
        printf("You have reached the maximum capacity of the class. You have 5 students in the class:\n");
    }
    else{
        printf("You have %d students in the class:\n",(5 - remaining_spots));
    }
    for(int i = 0; i < original_size; i++){
        if(student_array[i].studentID != 0){
        printf("%d, %s\n",student_array[i].studentID,student_array[i].name);
        }
    }

    free(student_array);
}