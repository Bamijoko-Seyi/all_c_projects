#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

struct node *add_to_list(struct node *list, int n, char marker){
	struct node *new_node;
	new_node = malloc(sizeof(struct node));

	if(new_node == NULL){
		printf("Error: malloc failed in add_to_list\n");
		exit(EXIT_FAILURE);
	}

	new_node->value = n;
	new_node->marker = marker;
	new_node->next = list;

	return new_node;
}

struct node *find_last(struct node *list, int n){
    struct node *p;
	struct node *last_occurance = NULL;
    for (p = list; p != NULL; p = p->next){
    if (p->value == n)
    last_occurance = p;
	}
	if(last_occurance != NULL){
		return last_occurance;
	}
	else{
	return NULL;
	}
}

void free_list(struct node *list){
	struct node *next_node;
    while (list != NULL) {
        next_node = list->next;
        free(list);
        list = next_node;
    }
}
