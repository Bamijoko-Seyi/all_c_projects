void push(int size, char *stack[], char *new_character);
char * pop(int size, char *stack[]) ;
int is_empty(int size, char * stack[]);
int is_full(int size, char * stack[]);
