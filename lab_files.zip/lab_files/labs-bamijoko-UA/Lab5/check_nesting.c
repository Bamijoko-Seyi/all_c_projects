#include <stdio.h>
#include <string.h>
#include "stack.h"

//next step use two arrays "left" and right to push and pop systematicaly

int main(){
char input[40];
char parentheses[10] ,*left_parenthesis[] = {".", ".", ".", ".", ".","."},*right_parenthesis[] = {".", ".", ".", ".", ".","."}, *new_character;
int i, j = 0, valid = 1;
for(i = 0; i < 40; i++){
    input[i] = '.'; 
}

for(i = 0; i < 10; i++){
    parentheses[i] = '.';
}

printf("Enter parentheses and/or braces:");
scanf("%[^\n]", input);

for(i = 0; input[i] != '\0'; i++){
        if(input[i] != ' '){
            input[j] = input[i];
            j++;
        }
    }
    input[j] = '\0';

j = 0;
for (i = 0; i < 40 && input[i] != '\0'; i++) {
    if (input[i] == '(' || input[i] == ')' || input[i] == '{' || input[i] == '}') {
        if (j < 10) {
            parentheses[j] = input[i];
            j++;
        } else {
            break;
        }
    }
}

j=0;
for (i = 0; i < 10; i++) {
        if (parentheses[i] == '(' || parentheses[i] == '{') {
            if(parentheses[i] == '('){
                new_character = "(";
            }
            else{
                new_character = "{";
            }
            push(5,left_parenthesis,new_character);
        }

    else if (parentheses[i] == ')' || parentheses[i] == '}') {
            if(parentheses[i] == ')'){
                new_character = ")";
            }
            else{
                new_character = "}";
            }
            push(6,right_parenthesis,new_character);
        }
}

for(i = 0 ; i < 10; i++){
    if(parentheses[i] == '('){
        for(j = 0 ; j < 6; j++){
            if(strcmp(right_parenthesis[j],")") == 0){
                if(is_empty(6,right_parenthesis)!= 1){
                pop(6,right_parenthesis);
                pop(6,left_parenthesis);
                }
                else{
                    push(6,left_parenthesis,"(");
                    break;
                }
            }
        }
    }

    else if(parentheses[i] == '{'){
        for(j = 0 ; j < 5; j++){
            if(strcmp(right_parenthesis[j],"}") == 0){
                if(is_empty(6,right_parenthesis)!= 1){
                pop(6,right_parenthesis);
                pop(6,left_parenthesis);
                }
                else{
                    push(6,left_parenthesis,"{");
                    break;
                    
                }
            }
        }
    }
}

if((is_empty(6,right_parenthesis) != 1) || (is_empty(6,left_parenthesis) != 1)){
    valid = 0;
}

if(valid == 1){
    printf("Parentheses are nested properly \n");
}
else {
    printf("Parentheses are not nested properly \n");
}

    return 0;
}
