//remember to initialize the array using the period 
#include <stdio.h>
#include <stdlib.h>
void push(int size, char *stack[], char *new_character);
char * pop(int size, char *stack[]) ;
int is_empty(int size, char * stack[]);
int is_full(int size, char * stack[]);

void push(int size, char *stack[], char *new_character){
    char *current_character = stack[0];
    char *temp;
    int i;
    
    if (is_full(size, stack) == 1) {
        fprintf(stderr, "Stack overflow \n");
        exit(0);
    } else if (is_empty(size, stack) == 1) {
        stack[0] = new_character;
    } else if (is_full(size, stack) == 0) {
        temp = stack[0];
        for (i = 0; i < size - 1; i++) {
            if (*stack[i + 1] != '.') {
                current_character = temp;
                temp = stack[i + 1];
                stack[i + 1] = current_character;
            } else {
                stack[i + 1] = current_character;
                break;
            }
        }
        stack[0] = new_character;
    }
}
    /*
    else{
        //error 
    }
    fix the error in the main code
    */
   
char * pop(int size, char *stack[]) {
    char *temp;
    int i, last_value = 0;
    char *popped = stack[0];

    if(is_empty(size, stack) == 1){
        return NULL;
    }
    else {
        for(i = 0; i < size; i++){
            if(stack[i][0] == '.'){
                last_value = (i - 1);
                break;
            }
        }
        for(i = 0; i < last_value; i++){
            temp = stack[i + 1];
            stack[i] = temp;
        }
        stack[last_value] = ".";
    }
    return popped;
}



int is_empty(int size, char * stack[]){
    int i,check = 1;
    // 0 = false, 1 = true 
    for(i = 0; i < size; i++){
        if(*stack[i] != '.'){
            check = 0;
            break;
        }
    }
    return check;
}

int is_full(int size, char * stack[]){
    int i, check = 1;
    for(i = 0; i < size; i++){
        if(*stack[i] == '.'){
            check = 0;
            break;
        }
    }
    return check;
}