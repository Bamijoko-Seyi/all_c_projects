 /*******************************************
 compare_dates

 Author: Bammijoko Oluwaseyfunmi 
 Last updated: 1/25/23
 *******************************************/

#include <stdio.h>
#include <stdlib.h>
  
   int main(int argc, char * argv[]){
    
       FILE *fp;
       char file_date[10];
	   char user_input[10];

      fp = fopen(argv[1], "r");
      fgets(file_date, 100, fp);

      printf("Enter date to compare to (mm/dd/yy) ");
      fgets(user_input ,10, stdin);

	  //initialising the user's date, month and year 
      int user_month = ((user_input[0] - '0')* 10 +(user_input[1] - '0'));
      int user_day = ((user_input[3] - '0')* 10 +(user_input[4] - '0'));
      int user_year  = ((user_input[6] - '0')* 10 +(user_input[7] - '0'));
	
	  //used for checking if the users input is valid  
      int correct_month = 0;
      int correct_year = 0;
      if (user_input[2]== '/' && user_input[5] == '/') {
          if (user_month >= 1 && user_month <= 12){
              if((user_month == 4 || user_month  == 6 || user_month == 9 || user_month == 11) && (user_day >= 1 && user_day<= 30)){
                  correct_month = 1;
                  }
              else if((user_month == 2) && (user_day >= 1 && user_day <= 28)){
                  correct_month = 1;
                  }
              else if((user_month != 4 || user_month  != 6 || user_month != 9 || user_month != 11 || user_month != 2) && (user_day >= 1 && user_day <= 31)){
                  correct_month = 1;
				  if(user_month == 2){
					  correct_month = 0;
				  }
                  }
              else {correct_month = 0;}
          }
          if (user_year >= 1 && user_year <= 99){
            correct_year = 1; 
          }
      }
    else {
	    fprintf(stderr,"Wrong date format\n");
		fclose(fp);
		exit(4);
    } 
    
	//initialising the file's date, month and year 
    if (correct_month == 1 && correct_year == 1){
    int file_year = ((file_date[6] - '0')* 10 +(file_date[7] - '0'));
    int file_month  = ((file_date[0] - '0')* 10 +(file_date[1] - '0'));
      int file_day = ((file_date[3] - '0')* 10 +(file_date[4] - '0'));
    
	//compare both dates and see which is earlier
    if (file_year > user_year){
        printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",file_month,file_day,file_year,user_month,user_day,user_year);
        }
    else if (file_year < user_year){
        printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",user_month,user_day,user_year,file_month,file_day,file_year);
        }

    else {
        if (file_month > user_month){
			printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",file_month,file_day,file_year,user_month,user_day,user_year);
        }
        else if (file_month < user_month){
            printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",user_month,user_day,user_year,file_month,file_day,file_year);
        }
        else {
             if (file_day > user_day){
                printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",file_month,file_day,file_year,user_month,user_day,user_year);
        }
            else if (file_day < user_day){
                printf("%02d/%02d/%02d is earlier than %02d/%02d/%02d \n",user_month,user_day,user_year,file_month,file_day,file_year);
            }
            else {
                printf("both are equal \n");
            }
        }
    }
    }
	else {
		 fprintf(stderr, "Wrong date format\n");
		 fclose(fp);
		 exit(4);
	  }

    fclose(fp);
    return 0;
    }
 

