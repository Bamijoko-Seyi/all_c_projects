rm f1.txt
rm f2.txt
