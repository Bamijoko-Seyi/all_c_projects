chmod +x create_files.sh
./create_files.sh
diff --ignore-file-name-case f1.txt f2.txt
