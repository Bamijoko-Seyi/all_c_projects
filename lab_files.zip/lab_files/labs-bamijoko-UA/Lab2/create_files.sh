#!/bin/bash
echo "This is f1" > f1.txt
echo "\n This is f1" > f2.txt 

