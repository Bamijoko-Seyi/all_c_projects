#include <stdio.h>
#include <string.h>
int check_palindrome(char input[]);

int check_palindrome(char input[]){
    char stripped_character[100], reversed_character[100];
    int stripped_size = 0, j = 0;

    for (int i = 0; i < 100; i++) {
        if (*(input + i) == '\0') {
            break;
        }

        if ((*(input + i) >= 'A' && *(input + i) <= 'Z') || (*(input + i) >= 'a' && *(input + i) <= 'z')) {
            if (*(input + i) >= 'A' && *(input + i) <= 'Z') {
                *(stripped_character + stripped_size) = *(input + i) + ('a' - 'A');
            } else {
                *(stripped_character + stripped_size) = *(input + i);
            }
            stripped_size++;
        }
    }

    *(stripped_character + stripped_size) = '\0';
    for (int i = stripped_size - 1; i >= 0; i--) {
        *(reversed_character + j) = *(stripped_character + i);
        j++;
    }
    *(reversed_character + stripped_size) = '\0';

    if ((strcmp(stripped_character, reversed_character) == 0)) {
        return 0;
    } else {
        return 1;
    }
}


int main() {
    char input[100];
    int valid;
    printf("Enter a message: ");
    fgets(input, sizeof(input), stdin);  // read a line of text from the user
    valid = check_palindrome(input);
    if(valid == 0){
        printf("Palindrome \n");
    }
    else if(valid == 1){
        printf("Not a palindrome \n");
    }
    return 0;
}