#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 20

int get_extension(const char *file_name);

int get_extension(const char *file_name){
    int string_len, period_position = 0, j = 0, extension_length;
    char *extensions[] = {".txt",".out",".bkp",".dot",".tx"};
    string_len = strlen(file_name);
    for(int i = 0; i < string_len; i++){
        if(file_name[i] == '.'){
            period_position = i;
        }
    }
    extension_length = string_len - period_position;
    char extension[extension_length + 1];
    for(int i = period_position; i < string_len; i++){
        extension[j] = file_name[i];
        j++;
    }

    extension[extension_length] = '\0';
    for(int i = 0; i < 5; i++){
        if((strcmp(extension,extensions[i]) == 0)){
            return i;
        }
    }
    printf("%s extension \n",extension);
    return -1;
}
int main(int argc, char* argv[]){
	
	//simplifying things and not doing any argument validation
    printf("The index value of the extension of the input file is: %d\n", get_extension(argv[1]));
}
