/*******************************************
 Search.c

 Author: Bammijoko Oluwaseyfunmi 
 Last updated: 2/1/23
*******************************************/

#define  _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char * argv[]){

    if (argc == 3 && atoi(argv[2]) >= 0 && atoi(argv[2]) <= 45 ){
       FILE *fp;
       int i, thresh_hold_letters = 0;
       char alphabet_array[26] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
       int appearance[26] = {0};
       char word;
    
       fp = fopen(argv[1], "r");

       //checks if the file exists
       if (fp == NULL){ 
            fprintf(stderr, "ERROR: cannot find %s\n", argv[1]);
            exit(4);
            fclose(fp);
            }

        else{
            word = fgetc(fp); //gets a character from the file and doesnt stop until it has reached the end 
            while(word != EOF){
                    //looks for a particular letter and stores its appearance in an array 
                    switch(word){
                        case 'a':
                            appearance[0] = appearance[0] + 1;
                            break;
                        case 'b':
                            appearance[1] = appearance[1] + 1;
                            break;
                        case 'c':
                            appearance[2] = appearance[2] + 1;
                            break;
                        case 'd':
                            appearance[3] = appearance[3] + 1;
                            break;
                        case 'e':
                            appearance[4] = appearance[4] + 1;
                            break;
                        case 'f':
                            appearance[5] = appearance[5] + 1;
                            break;
                        case 'g':
                            appearance[6] = appearance[6] + 1;
                            break;
                        case 'h':
                            appearance[7] = appearance[7] + 1;
                            break;
                        case 'i':
                            appearance[8] = appearance[8] + 1;
                            break;
                        case 'j':
                            appearance[9] = appearance[9] + 1;
                            break;
                        case 'k':
                            appearance[10] = appearance[10] + 1;
                            break;
                        case 'l':
                            appearance[11] = appearance[11] + 1;
                            break;
                        case 'm':
                            appearance[12] = appearance[12] + 1;
                            break;
                        case 'n':
                            appearance[13] = appearance[13] + 1;
                            break;
                        case 'o':
                            appearance[14] = appearance[14] + 1;
                            break;
                        case 'p':
                            appearance[15] = appearance[15] + 1;
                            break;
                        case 'q':
                            appearance[16] = appearance[16] + 1;
                            break;
                        case 'r':
                            appearance[17] = appearance[17] + 1;
                            break;
                        case 's':
                            appearance[18] = appearance[18] + 1;
                            break;
                        case 't':
                            appearance[19] = appearance[19] + 1;
                            break;
                        case 'u':
                            appearance[20] = appearance[20] + 1;
                            break;
                        case 'v':
                            appearance[21] = appearance[21] + 1;
                            break;
                        case 'w':
                            appearance[22] = appearance[22] + 1;
                            break;
                        case 'x':
                            appearance[23] = appearance[23] + 1;
                            break;
                        case 'y':
                            appearance[24] = appearance[24] + 1;
                            break;
                        case 'z':
                            appearance[25] = appearance[25] + 1;
                            break;
                            
                    }
                word = fgetc(fp);
            }
                //used to print all occurences of a particular letter that meets the threshold 
                for(i = 0; i < 26; i++){
                    if(appearance[i] >= atoi(argv[2]) && (appearance[i]!= 0)){
                        if(appearance[i] == 1){
                            printf("%c appears %d time \n",alphabet_array[i], appearance[i]);
                        }
                        else{
                            printf("%c appears %d times \n",alphabet_array[i], appearance[i]);
                        }
                        thresh_hold_letters++;
                    }   
                }

                if (thresh_hold_letters == 0){
                        printf("There are no letters that exceed this threshold \n");
                    }


            fclose(fp);
            
        }
    }
    else{
        fprintf(stderr,"Wrong input format\n");
        exit(4);
        
    }

    return 0;
}