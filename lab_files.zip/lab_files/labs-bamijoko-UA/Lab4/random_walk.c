/*******************************************
 random_walk
 Author: Bammijoko Oluwaseyfunmi 
 Last updated: 2/8/23
 *******************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void generate_random_walk (int n, int m, char walk[n][m]);
void print_array (int n, int m, char walk[n][m]);

void print_array (int n, int m, char walk[n][m]){
    int i,j;
    for (i = 0; i < n; i++){
        for (j = 0; j < m; j++){
            printf("%c ", walk[i][j]);
        }
        printf("\n");
    }
}

void generate_random_walk(int n, int m, char walk[n][m]){
    srand(time(0));
    int i, j,current_character = 0,current_row = 0, current_column = 0, random_number, end = 0, tried_attempts = 0;
    for(i = 0; i < n; i++){
        for(j = 0; j < m; j++){
         walk[i][j] = '.'; 
        }
    }
    static char alphabet_array[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
 
 walk[current_row][current_column] = alphabet_array[current_character];
    while(end == 0){
        random_number = (rand() % 4);

        //up = 0, down = 1, left = 2, right = 3
        if (alphabet_array[current_character] == 'Z'){
            end = 1;
        }
        else if (random_number == 0 && ((current_row - 1) >= 0) && (walk[current_row - 1][current_column] == '.') ){
                current_character++;
                current_row--;
                walk[current_row][current_column] = alphabet_array[current_character];
                tried_attempts = 0;
        }

        else if(random_number == 1 && ((current_row + 1) <= (n - 1)) && (walk[current_row + 1][current_column] == '.')){
                current_character++;
                current_row++;
                walk[current_row][current_column] = alphabet_array[current_character];
                tried_attempts = 0;
        }

         else if(random_number == 2 && ((current_column - 1) >= 0) && (walk[current_row ][current_column - 1] == '.')){
                current_character++;
                current_column--;
                walk[current_row][current_column] = alphabet_array[current_character];
                tried_attempts = 0;
                }
                
         else if(random_number == 3 && ((current_column + 1) <= (m - 1)) && (walk[current_row ][current_column + 1] == '.')){
                current_character++;
                current_column++;
                walk[current_row][current_column] = alphabet_array[current_character];
                tried_attempts = 0;
                }

         else if(current_row == n && current_column == 0 && walk[n - 1][0] != '.' && walk[n][m + 1] != '.'){
            end = 1;
         }

         else if(current_row == 0 && current_column == m && walk[0][m - 1] != '.' && walk[1][m] != '.'){
            end = 1;
         }

         else if(current_row == n && current_column == m && walk[n][m - 1] != '.' && walk[n - 1][m] != '.'){
            end = 1;
         }
         
         else if(current_row == 0 && walk[0][current_column - 1] != '.' && walk[0][current_column + 1 ] != '.' && walk[1][current_column] != '.'){
            end = 1;
         }

          else if(current_row == n && walk[n][current_column - 1] != '.' && walk[n][current_column + 1 ] != '.' && walk[n - 1][current_column] != '.'){
            end = 1;
         }

          else if(current_column == 0 && walk[current_row + 1][0] != '.' && walk[current_row - 1][0] != '.' && walk[current_row][1] != '.'){
            end = 1;
         }

          else if(current_column == m && walk[current_row + 1][m] != '.' && walk[current_row - 1][m] != '.' && walk[current_row][m - 1] != '.'){
            end = 1;
         }
         
         else if (walk[current_row - 1][current_column] != '.' && walk[current_row + 1][current_column] != '.' && walk[current_row][current_column - 1] != '.' && walk[current_row][current_column + 1] != '.'){
            end = 1;
         }

         else if(alphabet_array[current_character] == 'Z' || tried_attempts == 30){
            end = 1;
         }
         
         //to stop it from going on infinitely 
         tried_attempts++;
        }

    printf("Walked until letter %c \n\n", alphabet_array[current_character]);
    print_array(n, m, walk);
}

int main(void){
    int row, column;
    

    printf("Enter number of rows: ");
    scanf("%d" , &row);
    printf("Enter number of columns: ");
    scanf("%d", &column);
    char walk[row][column];
    generate_random_walk(row,column,walk);

    return 0;
}