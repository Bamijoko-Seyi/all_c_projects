#include <stdio.h>
#include <stdlib.h>
int string_comparison(const char *string1, const char *string2);
void sorting(char *array[], int n);
void printing_result(char *array[], int n);
void free_memory(char *array[], int n);
void my_strcpy(char *dest, const char *src);
char char_checker(char character);

int string_comparison(const char *string1, const char *string2) {
    char temp_letter_string1 = char_checker(*string1), temp_letter_string2 = char_checker(*string2);

    while(char_checker(temp_letter_string1) == char_checker(temp_letter_string2) && temp_letter_string1 != '\0' && temp_letter_string2 != '\0'){
        temp_letter_string1 = *(string1++);
        temp_letter_string2 = *(string2++);
    }
    if(temp_letter_string1 > temp_letter_string2){
        return 1;
    } 
    else {
        return 0;
    }
}

// sorting function
// n is the length of the array
void sorting(char *array[], int n) {
    int i, j;
    char temp[100];
    for(i = 0; i < n-1; i++){
        for(j = 0; j < n-i-1; j++){
            if(string_comparison(array[j], array[j+1]) == 1){
                my_strcpy(temp, array[j]);
                my_strcpy(array[j], array[j+1]);
                my_strcpy(array[j+1], temp);
            }
        }
    }
  // TODO: sort your string array here
  // TODO: you should call string_comparison function in here
}

// print the result
// n is the length of the array
void printing_result(char *array[], int n) {
    printf("\nIn sorted order:");
    for(int i = 0; i < n; i++){
        printf(" %s",array[i]);
    }
    printf(".\n");
  // TODO: print the result
}

// free the memory allocated
// n is the length of the array
void free_memory(char *array[], int n) {
  // TODO: free memory
  for(int i = 0; i < n; i++){
        free(array[i]);
    }
}


/****** Helper Functions ******/
void my_strcpy(char *dest, const char *src){
    int i = 0;
    while (src[i] != '\0'){
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}
char char_checker(char character){
    if(character >= 'A' && character <= 'Z'){
        printf("%c see \n",(char)character + 32);
        return((char)character + 32);
    }
    else{
        return character;
    }
}




/******************************/
//#define n 20
int main(void) { 
  int n = 20;
  char *array[n];
  char input[n];
  int len = 0,num_words = 0,max_words = n, i = 0,equal = 1, j = 0;
  for(;;){
    if(num_words == max_words){
        break;
    }
    printf("Enter word: ");
    fgets(input, n, stdin);
    
    j = 0;
    while (input[j] != '\0'){
        if(input[j] == '\n'){
            input[j] = '\0';
            break;
        }
        j++;
    }

    i = 0,equal = 1;
    while (input[i] != '\0') {
        if (input[i] != '\n'){
            equal = 0;
            break;
        }
        i++;
    }
    if(equal == 1){
        if(num_words == 0){
            printf("\nNo words inserted.\n");
            exit(0);
            break;
        }
        break;
    }
    len = 0;
    while(input[len] != '\0'){
        len++;
    }
    array[num_words] = (char*) malloc(len + 1);
    my_strcpy(array[num_words], input);
    num_words++;
  }
    n = num_words;
  // TODO: initialize your array
  // TODO: initialize your length of the array n
  // TODO: get inputs and insert them to the array

  // sort the array

  sorting(array, n);
  // print
  printing_result(array, n);
  // free memory
  free_memory(array, n);

  return 0;
}