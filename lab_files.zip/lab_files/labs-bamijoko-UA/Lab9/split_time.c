#include <stdio.h>

typedef struct {
    int hours;
    int minutes;
    int seconds;
} time;

time split_time(long total_seconds);

time split_time(long total_seconds) {
    time t;
    int decimal_part;
    t.hours = (int)(total_seconds / 3600);
    decimal_part = total_seconds - t.hours * 3600;
    t.minutes = (int)(decimal_part / 60);
    decimal_part = decimal_part - t.minutes * 60;
    t.seconds = (int)decimal_part;
    return t;
}

int main() {
    int user_input;
    printf("Enter time as seconds since midnight: ");
    scanf("%d", &user_input);
    time t = split_time(user_input);
    printf("%02d:%02d:%02d\n", t.hours, t.minutes, t.seconds);
    return 0;
}
