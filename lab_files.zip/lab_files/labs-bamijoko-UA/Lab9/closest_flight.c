#include <stdio.h>
#include <stdlib.h>

typedef struct travel_time {
    int total_minutes_arrival;
    int total_minutes_departure;
}travel_time_struct;


int main(){
    int arrival_hours,depature_hours,arrival_minutes,depature_minutes;
    char* suffix[2] = {"a.m","a.m"};
    //setting alll the times
    travel_time_struct new[7];
    new[0].total_minutes_arrival = 481;
    new[0].total_minutes_departure = 617;

    new[1].total_minutes_arrival = 658;
    new[1].total_minutes_departure =791;
    
    new[2].total_minutes_arrival = 679;
    new[2].total_minutes_departure = 811;
    
    new[3].total_minutes_arrival = 767;
    new[3].total_minutes_departure = 900;
    
    new[4].total_minutes_arrival = 976;
    new[4].total_minutes_departure = 1110;
    
    new[5].total_minutes_arrival = 1162;
    new[5].total_minutes_departure = 1315;

    new[6].total_minutes_arrival = 1273;
    new[6].total_minutes_departure = 1405;

    int hours, minutes, total_minutes;
    printf("Enter a 24-hour time: ");
    scanf("%d:%d",&hours,&minutes);

    if((hours < 0 || hours > 23) || (minutes < 0 || minutes > 59)){
        printf("Invalid time entered.\n");
        exit(0);
    }

    total_minutes = (hours * 60) + minutes;
    for(int i = 0; i < 7; i++){
        if(i == 6 && new[i].total_minutes_arrival < total_minutes ){
            printf("Next flight is at 8:01 a.m, arriving at 10:17 a.m.\n");
            break;
        }
        if(new[i].total_minutes_arrival > total_minutes){
            arrival_hours = new[i].total_minutes_arrival / 60, depature_hours = new[i].total_minutes_departure / 60;
            arrival_minutes = new[i].total_minutes_arrival % 60, depature_minutes = new[i].total_minutes_departure % 60;
        if (arrival_hours >= 12) {
            suffix[0] = "p.m";
        }
        if (depature_hours >= 12) {
            suffix[1] = "p.m";
        }
        if (arrival_hours == 0) {
            arrival_hours = 12; // 12:00 AM instead of 00:00 AM
        } else if (arrival_hours > 12) {
            printf("%d %d\n",arrival_hours,i);
           arrival_hours -= 12; // convert to 12-hour format
        }
        if (depature_hours == 0) {
            depature_hours = 12; // 12:00 AM instead of 00:00 AM
        } else if (depature_hours > 12) {
            depature_hours -= 12; // convert to 12-hour format
        }

        printf("Next flight is at %02d:%02d %s, arriving at %02d:%02d %s\n",arrival_hours,arrival_minutes,suffix[0],depature_hours,depature_minutes,suffix[1]);
        break;
        }
    }

    return 0;
}