/*******************************************
Bill_calculator

Author: Bammijoko Oluwaseyfunmi
Last updated: 1/17/23
*******************************************/

#include <stdio.h>

int main(void){
	int user_input;
	int current_number;

//collects the information needed to calculate number of dollars needed
	printf("Enter a dollar amount:" );
	scanf("%d", &user_input);

//calculates the amount of dollars needed for each type of bill using "current_number to keep track	
	int twenty_dollars = user_input / 20;
	current_number = user_input - (twenty_dollars * 20);
	int ten_dollars = current_number / 10;
	current_number = current_number - (ten_dollars * 10);
	int five_dollars = current_number / 5;
	current_number = current_number - (five_dollars * 5);
	int one_dollar = current_number / 1;
  
	 printf ("$20 bills: %d \n$10 bills: %d \n$5 bills: %d \n$1 bills: %d \n", twenty_dollars, ten_dollars, five_dollars, one_dollar);
  
	 return 0;
}
