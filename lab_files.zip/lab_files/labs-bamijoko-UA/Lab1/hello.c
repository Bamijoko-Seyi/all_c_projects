/*************************************
Hello.c

Author: Bamijoko Oluwaseyifunmi
Last Updated:1/18/23
**************************************/
#include <stdio.h>

int main(void)
{
  printf( "Hello world!\n" );//Fixed the error caused by the missing ";"
  return 0;
}//Also fixed another error that was caused by not closing the main function using "}"

